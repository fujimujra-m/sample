﻿using Antlr4.Runtime.Misc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ladder
{
    class Visitor : LadderBaseVisitor<LadderResult>
    {
        override public LadderResult VisitNemonic([NotNull] LadderParser.NemonicContext context)
        {
            var result = new LadderResult();

            var inst = context.inst.GetText().ToUpper();
            var suffix = ".U";

            if (context.sfx != null)
            {
                suffix = context.sfx.GetText().ToUpper();
            }

            if (inst == "LD")
            {
                //関数化。。
                if (context._opes.Count != 1)
                {
                    result.Errors.Add(string.Format("オペランド数異常[{0}]", context.GetText()));
                    return result;
                }

                var ope1Result = Visit(context._opes[0]);

                if (!ope1Result.IsSuccess) return ope1Result;

                if (isRelayType(ope1Result.Type))
                {
                    //ビットアクセス
                    var ch = (int)(ope1Result.DevNo / 100);
                    var bit = ope1Result.DevNo % 100;

                    var dev = Program.Devices[ope1Result.Type][ch];
                    var bitval = (dev >> bit) & 0x1;

                    Program.BA = bitval == 1;
                }
                else
                {
                    var dev = Program.Devices[ope1Result.Type][ope1Result.DevNo];
                    var bitval = dev & 0x1;

                    Program.BA = bitval == 1;
                }

                result.IsSuccess = true;
            }
            else if (inst == "MOV")
            {
                if (context._opes.Count != 2)
                {
                    result.Errors.Add(string.Format("オペランド数異常[{0}]", context.GetText()));
                    return result;
                }

                var ope1Result = Visit(context._opes[0]);
                if (!ope1Result.IsSuccess) return ope1Result;
                var ope2Result = Visit(context._opes[1]);
                if (!ope2Result.IsSuccess) return ope2Result;

                //オペランドのチェックまではやってしまう。
                //以降は、母線がONのときだけ実行する
                if (Program.BA)
                {
                    //CHマタギとか未考慮。。
                    var devlen = 1;
                    if (suffix == ".D" || suffix == ".L" || suffix == ".F") devlen = 2;
                    if (suffix == ".DF") devlen = 4;

                    for (int i = 0; i < devlen; i++)
                    {
                        var srcno = ope1Result.DevNo + i;
                        var dstno = ope2Result.DevNo + i;

                        if (Program.Devices[ope1Result.Type].Length <= srcno)
                        {
                            result.Errors.Add(string.Format("range over.[src: {0}]", srcno));
                            return result;
                        }
                        if (Program.Devices[ope2Result.Type].Length <= dstno)
                        {
                            result.Errors.Add(string.Format("range over.[dst: {0}]", dstno));
                            return result;
                        }

                        var srcValue = Program.Devices[ope1Result.Type][srcno];
                        Program.Devices[ope2Result.Type][dstno] = srcValue;
                    }
                }
            }

            return result;
        }

        bool isRelayType(LadderResult.DevType type)
        {
            if (type == LadderResult.DevType.R) return true;
            return false;
        }

        override public LadderResult VisitModifiedoperand_index([NotNull] LadderParser.Modifiedoperand_indexContext context)
        {
            var rawoperand = context.rawoperand();
            var baseResult = Visit(rawoperand[0]);
            if (!baseResult.IsSuccess) return baseResult;


            if (rawoperand.Length == 2)
            {
                var indexDevResult = Visit(context.rawoperand()[1]);
                if (!indexDevResult.IsSuccess) return baseResult;

                var offset = Program.Devices[indexDevResult.Type][indexDevResult.DevNo];
                baseResult.DevNo += offset;
                if (baseResult.DevNo >= Program.Devices[baseResult.Type].Length)
                {
                    return new LadderResult() { Errors = new List<string>(new string[] { "index先が範囲外。"}) };
                }
            }
            else if (context.number() != null)
            {
                //直値の就職。
                return new LadderResult() { Errors = new List<string>(new string[] { "直値のIndexは未実装。" }) };
            }

            return baseResult;
        }

        override public LadderResult VisitRawoperand([NotNull] LadderParser.RawoperandContext context)
        {
            var result = new LadderResult();

            if (context.lcl != null)
            {
                result.Errors.Add("local operand is not supported.");
                return result;
            }

            var devstr = context.GetText();

            if (devstr.Length > 2 && devstr.Substring(0, 2).ToLower() == "dm")
            {
                result.Type = LadderResult.DevType.DM;
                result.DevNo = int.Parse(devstr.Substring(2));
                result.IsSuccess = true;
            }
            else if (devstr.Length > 1 && devstr.Substring(0, 1).ToLower() == "z")
            {
                result.Type = LadderResult.DevType.Z;
                result.DevNo = int.Parse(devstr.Substring(1));
                result.IsSuccess = true;
            }
            else if (devstr.Length > 1 && devstr.Substring(0, 1).ToLower() == "r")
            {
                result.Type = LadderResult.DevType.R;
                result.DevNo = int.Parse(devstr.Substring(1));
                result.IsSuccess = true;
            }

            return result;
        }

        override public LadderResult VisitInput([NotNull] LadderParser.InputContext context)
        {
            foreach (var nemonic in context.nemonic())
            {
                var result = Visit(nemonic);
                if (result == null)
                {
                    return new LadderResult() { Errors = new List<string>(new string[] { "unknown error" }) };
                }
                else if (!result.IsSuccess)
                {
                    return result;
                }
            }
            return new LadderResult() { IsSuccess = true };
        }
        override public LadderResult VisitNumber([NotNull] LadderParser.NumberContext context)
        {
            var result = new LadderResult();

            //決め打ち
            result.Type = LadderResult.DevType.IMM;
            result.Value = double.Parse(context.GetText());

            return result;
        }
    }
}
