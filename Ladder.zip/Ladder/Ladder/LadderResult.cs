﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ladder
{
    class LadderResult
    {
        public bool IsSuccess { get; set; } = false;

        public List<string> Errors { get; set; } = new List<string>();

        public enum DevType { DM, R, Z, IMM };

        public DevType Type { get; set; }
        public int DevNo { get; set; }
        public object Value { get; set; }
    }
}
