﻿using Antlr4.Runtime;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ladder
{
    class Program
    {
        static void Main(string[] args)
        {
            Devices.Add(LadderResult.DevType.DM, new Int16[65535]);
            Devices.Add(LadderResult.DevType.Z, new Int16[12]);         //ほんとは32だけど。。
            Devices.Add(LadderResult.DevType.R, new Int16[10000]);

            Devices[LadderResult.DevType.R][0] = 0x1;
            Devices[LadderResult.DevType.R][1] = 0x02;
            Devices[LadderResult.DevType.DM][0] = 777;
            Devices[LadderResult.DevType.Z][0] = 1;
            Devices[LadderResult.DevType.Z][1] = 2;
            Devices[LadderResult.DevType.Z][2] = 0;

            while (true)
            {
                System.Console.Write("input>");
                var input = System.Console.ReadLine();

                var charStream = new AntlrInputStream(input);
                var lexer = new LadderLexer(charStream);
                var tokenStream = new CommonTokenStream(lexer);
                var parser = new LadderParser(tokenStream);

                var inputTree = parser.input();


                var visitor = new Visitor();
                var result = visitor.Visit(inputTree);


                if (result != null && !result.IsSuccess)
                {
                    Console.WriteLine(string.Join("\n", result.Errors));
                }

                //テスト用にいくつか情報を毎回出しとく
                Console.WriteLine("BA: {0}", Program.BA);
                Console.WriteLine("R000: {0}, R100: {1}", Program.Devices[LadderResult.DevType.R][0], Program.Devices[LadderResult.DevType.R][1]);
                Console.WriteLine("DM0,1,2: {0}, {1}, {2}", Program.Devices[LadderResult.DevType.DM][0],
                                                            Program.Devices[LadderResult.DevType.DM][1],
                                                            Program.Devices[LadderResult.DevType.DM][2]
                                                            );
                Console.WriteLine("DM10,11,12: {0}, {1}, {2}", Program.Devices[LadderResult.DevType.DM][10],
                                                            Program.Devices[LadderResult.DevType.DM][11],
                                                            Program.Devices[LadderResult.DevType.DM][12]
                                                            );
                Console.WriteLine("Z0,1,2: {0}, {1}, {2}", Program.Devices[LadderResult.DevType.Z][0],
                                                            Program.Devices[LadderResult.DevType.Z][1],
                                                            Program.Devices[LadderResult.DevType.Z][2]
                                                            );
            }

            System.Console.WriteLine("hit any key to quit.");
            System.Console.ReadKey();
        }

        internal static bool BA { get; set; }
        internal static Int32 ACC { get; set; }
        internal static Dictionary<LadderResult.DevType, Int16[]> Devices = new Dictionary<LadderResult.DevType, Int16[]>();
    }
}
