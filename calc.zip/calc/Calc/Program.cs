﻿using Antlr4.Runtime;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calc
{
    class Program
    {
        static void Main(string[] args)
        {
            //            var filename = args[0];
#if false
            var filename = "input.txt";
            var fs = File.OpenRead(filename);
            var charStream = new AntlrInputStream(fs);
#endif

            while (true)
            {
                System.Console.Write("input>");
                var input = System.Console.ReadLine();

                var charStream = new AntlrInputStream(input);
                var lexer = new CalculatorLexer(charStream);
                var tokenStream = new CommonTokenStream(lexer);
                var parser = new CalculatorParser(tokenStream);

                var inputTree = parser.input();


                System.Console.WriteLine("now calculating..");
                var visitor = new Visitor();

                visitor.AddFunction("sin", func_args => {
                    var func_result = new CalcResult() { IsSuccess = false, Value = 0 };

                    if (func_args.Length != 1)
                    {
                        func_result.Errors.Add("args error");
                        return func_result;
                    }

                    var argtype = func_args[0].GetType();
                    if (func_args[0].GetType() == typeof(string))
                    {
                        func_result.Errors.Add("type error");
                        return func_result;
                    }

                    func_result.IsSuccess = true;
                    func_result.Value = Math.Sin(Convert.ToDouble(func_args[0]));

                    return func_result;
                });

                visitor.AddFunction("Length", func_args => {
                    var func_result = new CalcResult() { IsSuccess = false, Value = 0 };

                    if (func_args.Length != 1)
                    {
                        func_result.Errors.Add("args error");
                        return func_result;
                    }

                    var argtype = func_args[0].GetType();
                    if (func_args[0].GetType() != typeof(string))
                    {
                        func_result.Errors.Add("type error");
                        return func_result;
                    }

                    func_result.IsSuccess = true;
                    func_result.Value = ((string)func_args[0]).Length;

                    return func_result;
                });
                var result = visitor.Visit(inputTree);

                System.Console.WriteLine("result:[{0}]", inputTree.GetText());
                if (result.IsSuccess)
                {
                    System.Console.WriteLine("[{1}] {0}", result.Value, result.Value.GetType().Name);
                }
                else
                {
                    System.Console.WriteLine("Error:");
                    System.Console.WriteLine(string.Join("\n", result.Errors));
                }
            }

            System.Console.WriteLine("hit any key to quit.");
            System.Console.ReadKey();
        }
    }
}
