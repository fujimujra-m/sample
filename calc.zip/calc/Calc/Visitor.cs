﻿using Antlr4.Runtime;
using Antlr4.Runtime.Misc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calc
{
    class Visitor : CalculatorBaseVisitor<CalcResult>
    {
        override public CalcResult VisitExpr_addsub([NotNull] CalculatorParser.Expr_addsubContext context)
        {
            return caluclulateExpr(context.op.Type, context.lhs, context.rhs);
        }

        private CalcResult caluclulateExpr(int op, ParserRuleContext expr_lhs, ParserRuleContext expr_rhs)
        {
            var lhs = Visit(expr_lhs);
            var rhs = Visit(expr_rhs);
            var result = new CalcResult() { IsSuccess = false, Value = 0 };

            if (rhs == null || !rhs.IsSuccess)
            {
                if (rhs == null)
                {
                    result.Errors.Add(string.Format("invalid expression (rhs)[{0}]", expr_rhs.GetText()));
                }
                else
                {
                    result.Errors.AddRange(rhs.Errors);
                }
                return result;
            }
            if (lhs == null || !lhs.IsSuccess)
            {
                if (lhs == null)
                {
                    result.Errors.Add(string.Format("invalid expression (lhs)[{0}]", expr_lhs.GetText()));
                }
                else
                {
                    result.Errors.AddRange(lhs.Errors);
                }
                return result;
            }
            else
            {
                result = calculate(op, lhs.Value, rhs.Value);
            }

            return result;
        }

        private CalcResult calculate(int op, object lhs, object rhs)
        {
            var lhstype = lhs.GetType();
            var rhstype = rhs.GetType();

            var tmp = lhs.GetType();

            if (lhstype == typeof(string))
            {
                return calculateStr(op, (string)lhs, rhs);
            }
            else if (lhstype == typeof(int) && rhstype == typeof(int))
            {
                return calculateInt(op, (int)lhs, (int)rhs);
            }
            else
            {
                return calculateFloat(op, Convert.ToDouble(lhs), Convert.ToDouble(rhs));
            }
        }
        private CalcResult calculateInt(int op, int lhs, int rhs)
        {
            var result = new CalcResult();

            switch (op)
            {
                case CalculatorLexer.PLUS:
                    result.IsSuccess = true;
                    result.Value = lhs + rhs;
                    break;
                case CalculatorLexer.MINUS:
                    result.IsSuccess = true;
                    result.Value = lhs - rhs;
                    break;
                case CalculatorLexer.ASTA:
                    result.IsSuccess = true;
                    result.Value = lhs * rhs;
                    break;
                case CalculatorLexer.SLASH:
                    result.IsSuccess = true;
                    result.Value = lhs / rhs;
                    break;
                case CalculatorParser.HAT:
                    result.IsSuccess = true;
                    result.Value = Math.Pow(lhs, rhs);
                    break;
                default:
                    result.Errors.Add("unknown operation type.");
                    break;
            }

            return result;
        }
        private CalcResult calculateFloat(int op, double lhs, double rhs)
        {
            var result = new CalcResult();

            if (double.IsNaN(lhs) || double.IsNaN(rhs))
            {
                result.Errors.Add("NaN Error");
                return result;
            }

            switch (op)
            {
                case CalculatorLexer.PLUS:
                    result.IsSuccess = true;
                    result.Value = lhs + rhs;
                    break;
                case CalculatorLexer.MINUS:
                    result.IsSuccess = true;
                    result.Value = lhs - rhs;
                    break;
                case CalculatorLexer.ASTA:
                    result.IsSuccess = true;
                    result.Value = lhs * rhs;
                    break;
                case CalculatorLexer.SLASH:
                    result.IsSuccess = true;
                    result.Value = lhs / rhs;
                    break;
                case CalculatorParser.HAT:
                    result.IsSuccess = true;
                    result.Value = Math.Pow(lhs, rhs);
                    break;
                default:
                    result.Errors.Add("unknown operation type.");
                    break;
            }

            return result;
        }
        private CalcResult calculateStr(int op, string lhs, object rhs)
        {
            var result = new CalcResult();

            var rhstype = rhs.GetType();

            switch (op)
            {
                case CalculatorLexer.PLUS:
                    if (rhstype == typeof(string))
                    {
                        result.IsSuccess = true;
                        result.Value = lhs + (string)rhs;
                    }
                    else
                    {
                        result.Errors.Add("invalid operation type.");
                    }
                    break;
                case CalculatorLexer.MINUS:
                    result.Errors.Add("invalid operation type.");
                    break;
                case CalculatorLexer.ASTA:
                    if (rhstype == typeof(int))
                    {
                        result.IsSuccess = true;
                        result.Value = string.Concat(Enumerable.Repeat(lhs, (int)rhs).ToArray());
                    }
                    else
                    {
                        result.Errors.Add("invalid operation type.");
                    }
                    break;
                case CalculatorLexer.SLASH:
                    result.Errors.Add("invalid operation type.");
                    break;
                case CalculatorParser.HAT:
                    result.Errors.Add("invalid operation type.");
                    break;
                default:
                    result.Errors.Add("unknown operation type.");
                    break;
            }

            return result;
        }

        override public CalcResult VisitNum([NotNull] CalculatorParser.NumContext context)
        {
            var result = new CalcResult();

            switch (context.Start.Type)
            {
                case CalculatorLexer.INT:
                    int int_num;
                    if (int.TryParse(context.GetText(), out int_num))
                    {
                        result.IsSuccess = true;
                        result.Value = int_num;
                    }
                    else
                    {
                        result.Errors.Add("invalid argument[NUM].");
                    }
                    break;
                case CalculatorLexer.FLOAT:
                    double float_num;
                    if (double.TryParse(context.GetText(), out float_num))
                    {
                        result.IsSuccess = true;
                        result.Value = float_num;
                    }
                    else
                    {
                        result.Errors.Add("invalid argument[NUM].");
                    }
                    break;
                default:
                    result.Errors.Add("invalid argument[NUM].");
                    break;
            }

            return result;
        }
        override public CalcResult VisitText([NotNull] CalculatorParser.TextContext context)
        {
            return new CalcResult() { IsSuccess = true, Value = context.GetText().Trim('"') };
        }
        override public CalcResult VisitConst([NotNull] CalculatorParser.ConstContext context)
        {
            var constStr = context.GetText();

            if (constStr == "PI")
            {
                return new CalcResult() { IsSuccess = true, Value = Math.PI };
            }

            return new CalcResult() { Errors = new List<string>(new string[] { string.Format("invalid operand[{0}]", constStr) }) };
        }

        override public CalcResult VisitExpr_mul([NotNull] CalculatorParser.Expr_mulContext context)
        {
            return caluclulateExpr(CalculatorLexer.ASTA, context.lhs, context.rhs);
        }

        override public CalcResult VisitExpr_muldiv([NotNull] CalculatorParser.Expr_muldivContext context)
        {
            return caluclulateExpr(context.op.Type, context.lhs, context.rhs);
        }
        override public CalcResult VisitExpr_power([NotNull] CalculatorParser.Expr_powerContext context)
        {
            return caluclulateExpr(CalculatorParser.HAT, context.lhs, context.rhs);
        }

        override public CalcResult VisitExpr_sign([NotNull] CalculatorParser.Expr_signContext context)
        {
            var result = Visit(context.rhs);

            if (result == null || !result.IsSuccess)
            {
                if (result == null)
                {
                    result = new CalcResult() { IsSuccess = false, Value = 0 };
                    result.Errors.Add("sign error");
                }
                return result;
            }

            if (context.op.Type == CalculatorLexer.MINUS)
            {
                return calculate(CalculatorLexer.MINUS, 0, result.Value);
            }

            return result;
        }

        internal delegate CalcResult FuncDelegate(params object[] args);
        Dictionary<string, FuncDelegate> functionDict = new Dictionary<string, FuncDelegate>();
        internal void AddFunction(string functionName, FuncDelegate function)
        {
            functionDict.Add(functionName.ToLower(), function);
        }


        override public CalcResult VisitExpr_funccall([NotNull] CalculatorParser.Expr_funccallContext context)
        {
            var result = new CalcResult();
            var args_result = context._args.Select(arg => Visit(arg));

            var err_args = args_result.Where(obj => !obj.IsSuccess);
            if (err_args.Count() != 0)
            {
                foreach (var err in err_args) result.Errors.AddRange(err.Errors);
                return result;
            }

            var functionname = context.funcname.Text.ToLower();
            if (!functionDict.ContainsKey(functionname))
            {
                result.Errors.Add("invalid functionname");
                return result;
            }

            var args = args_result.Select(obj => obj.Value).ToArray();
            return functionDict[functionname](args);
        }

        override public CalcResult VisitInput([NotNull] CalculatorParser.InputContext context)
        {
            //そのままだと、戻り値がNULL。。。EOFを訪れるとNULLが返ってるのかな？
            var result = Visit(context.expr());

            if (result == null)
            {
                result = new CalcResult();
                result.Errors.Add("unknown error.");
            }

            return result;
        }
        override public CalcResult VisitParenthesis_expr([NotNull] CalculatorParser.Parenthesis_exprContext context)
        {
            return Visit(context.expr());
        }

    }

    class CalcResult
    {

        public bool IsSuccess { get; set; } = false;

        public object Value { get; set; } = 0;

        public List<string> Errors { get; set; } = new List<string>();
    }
}
