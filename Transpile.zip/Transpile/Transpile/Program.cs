﻿using Antlr4.Runtime;
using ST;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Transpile
{
    class Program
    {
        static void Main(string[] args)
        {
            //            var filename = "test_expr_input.txt";
            var filename = "test_stmt_input.txt";

            var fs = File.OpenRead(filename);
            var charStream = new AntlrInputStream(fs);

            var lexer = new structured_textLexer(charStream);
            var tokenStream = new CommonTokenStream(lexer);
            var parser = new structured_textParser(tokenStream);

            var inputTree = parser.input();


            var visitor = new Visitor();
            var result = visitor.Visit(inputTree);

            System.Console.WriteLine(result.Text);

            System.Console.WriteLine("hit any key to quit.");
            System.Console.ReadKey();
        }
    }
}
