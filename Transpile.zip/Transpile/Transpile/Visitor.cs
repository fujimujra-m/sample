﻿using Antlr4.Runtime.Misc;
using ST;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ST.structured_textParser;

namespace Transpile
{
    class Visitor : ST.structured_textBaseVisitor<TranspileResult>
    {
        #region statement
        public override TranspileResult VisitStatement_repeat([NotNull] structured_textParser.Statement_repeatContext context)
        {
            var statementResult = Visit(context.statements());
            if (!statementResult.IsSuccess) return statementResult;

            var exprResult = Visit(context.expr());
            if (!exprResult.IsSuccess) return exprResult;

            //statement にインデントをつける。
            var indent_statemnet = statementResult.Text.Split('\n').Select(line => string.Format("    {0}", line));
            return new TranspileResult()
            {
                IsSuccess = true,
                Text = string.Format("DO\n{0}\nUNTIL {1}", string.Join("\n", indent_statemnet), exprResult.Text)
            };
        }

        public override TranspileResult VisitStatement_case([NotNull] structured_textParser.Statement_caseContext context)
        {
            var exprResult = Visit(context.expr());
            if (!exprResult.IsSuccess) return exprResult;

            var result = new TranspileResult();
            var case_result = context.case_statement().Select(case_statement => Visit(case_statement));

            var err_args = case_result.Where(obj => !obj.IsSuccess);
            if (err_args.Count() != 0)
            {
                foreach (var err in err_args) result.Errors.AddRange(err.Errors);
                return result;
            }

            var case_statement_text = string.Join("\n", case_result.Select(obj => obj.Text));
            var indent_case_statement_text = string.Join("\n", case_statement_text.Split('\n').Select(obj => "    " + obj));

            return new TranspileResult()
            {
                IsSuccess = true,
                Text = string.Format("SELECT CASE {0}\n{1}\nEND SELECT", exprResult.Text, indent_case_statement_text)
            };
        }
        public override TranspileResult VisitCase_statements_condition([NotNull] structured_textParser.Case_statements_conditionContext context)
        {
            var result = new TranspileResult();
            var conds_result = context._conds.Select(cond => Visit(cond));

            var err_args = conds_result.Where(obj => !obj.IsSuccess);
            if (err_args.Count() != 0)
            {
                foreach (var err in err_args) result.Errors.AddRange(err.Errors);
                return result;
            }

            //###mada 条件をまとめないといけない。CASEがすとんと落ちるやつ。未実施。

            var statements = string.Empty;
            if (context.statements() != null)
            {
                var statements_result = Visit(context.statements());
                if (!statements_result.IsSuccess) return statements_result;
                //statement にインデントをつける。
                var indent_statemnet = statements_result.Text.Split('\n').Select(line => string.Format("    {0}", line));
                statements = string.Join("\n", indent_statemnet);
            }

            var conds_text = string.Join(",", conds_result.Select(cond => cond.Text));

            return new TranspileResult()
                {
                    IsSuccess = true,
                    Text = string.Format("CASE {0}\n{1}", conds_text, statements)
            };
        }
        public override TranspileResult VisitCase_statements_else([NotNull] structured_textParser.Case_statements_elseContext context)
        {
            var statements = string.Empty;
            if (context.statements() != null)
            {
                var statements_result = Visit(context.statements());
                if (!statements_result.IsSuccess) return statements_result;
                //statement にインデントをつける。
                var indent_statemnet = statements_result.Text.Split('\n').Select(line => string.Format("    {0}", line));
                statements = string.Join("\n", indent_statemnet);
            }

            return new TranspileResult()
            {
                IsSuccess = true,
                Text = string.Format("ELSE\n{0}", statements)
            };
        }
        public override TranspileResult VisitCase_statements_condition_single([NotNull] structured_textParser.Case_statements_condition_singleContext context)
        {
            return new TranspileResult() { IsSuccess = true, Text = context.IDENTIFIER().GetText() };
        }

        public override TranspileResult VisitCase_statements_condition_multi([NotNull] structured_textParser.Case_statements_condition_multiContext context)
        {
            var first = context.IDENTIFIER()[0].GetText();
            var second = context.IDENTIFIER()[1].GetText();
            return new TranspileResult() { IsSuccess = true, Text = string.Format("{0} TO {1}", first, second) };
        }

        public override TranspileResult VisitStatement_expr([NotNull] structured_textParser.Statement_exprContext context)
        {
            return Visit(context.expr());
        }

        public override TranspileResult VisitStatement_assign([NotNull] structured_textParser.Statement_assignContext context)
        {
            var result = Visit(context.statement());

            if (!result.IsSuccess)
            {
                return result;
            }

            var opeText = string.Empty;
            if (!GetOperatorText(structured_textLexer.ASSIGN, false, out opeText))
            {
                return new TranspileResult() { Errors = new List<string>() { "Unknown Operator Type" } };
            }

            var identifier = context.IDENTIFIER().GetText();

            return new TranspileResult() { IsSuccess = true, Text = string.Format("{0} {1} {2}", identifier, opeText, result.Text) };
        }

        public override TranspileResult VisitStatement_exit([NotNull] structured_textParser.Statement_exitContext context)
        {
            return new TranspileResult() { IsSuccess = true, Text = "BREAK" };
        }

        public override TranspileResult VisitStatement_return([NotNull] structured_textParser.Statement_returnContext context)
        {
            //###mada return 実装できてない。。
            //状態を覚えさせて、RETURNした以降の文を吐くときに、 if false をつけるのか。
            //case からの脱出の return は特別視する必要がある。
            return new TranspileResult() { IsSuccess = true, Text = "RETURN" };
        }

        #endregion
        #region expr
        public override TranspileResult VisitStatements([NotNull] structured_textParser.StatementsContext context)
        {
            var result = new TranspileResult();
            var statement_result = context.statement().Select(statement => Visit(statement));

            var err_statement = statement_result.Where(obj => !obj.IsSuccess);
            if (err_statement.Count() != 0)
            {
                foreach (var err in err_statement) result.Errors.AddRange(err.Errors);
                return result;
            }

            return new TranspileResult()
            {
                IsSuccess = true,
                Text = string.Join(";\n", statement_result.Select(statement => statement.Text))
            };
        }

        public override TranspileResult VisitNum_expression([NotNull] structured_textParser.Num_expressionContext context)
        {
            if (context.typespec != null)
            {
                var typespec = context.typespec.Text.ToLower();
                var text = string.Empty;

                if (typespec == "int") text = string.Format("TOS(#{0})", context.value.Text);
                else if (typespec == "uint") text = string.Format("TOU(#{0})", context.value.Text);
                else if (typespec == "dint") text = string.Format("TOL(#{0})", context.value.Text);
                else if (typespec == "udint") text = string.Format("TOD(#{0})", context.value.Text);
                else if (typespec == "real") text = string.Format("TOF(#{0})", context.value.Text);
                else if (typespec == "lreal") text = string.Format("TODF(#{0})", context.value.Text);

                return new TranspileResult() { IsSuccess = true, Text = text };
            }
            else
            {
                return new TranspileResult() { IsSuccess = true, Text = "#" + context.value.Text };
            }
        }

        public override TranspileResult VisitText_mbcs([NotNull] structured_textParser.Text_mbcsContext context)
        {
            return new TranspileResult() { IsSuccess = true, Text = string.Format("\"{0}\"", context.MBCS_STR().GetText().Trim('\'')) };
        }
        public override TranspileResult VisitText_wstr([NotNull] structured_textParser.Text_wstrContext context)
        {
            return new TranspileResult() { IsSuccess = true, Text = context.WSTR_STR().GetText() };
        }

        public override TranspileResult VisitExpr_identifier([NotNull] structured_textParser.Expr_identifierContext context)
        {
            return new TranspileResult() { IsSuccess = true, Text = context.GetText() };
        }
        public override TranspileResult VisitParenthesis_expr_comp([NotNull] structured_textParser.Parenthesis_expr_compContext context)
        {
            var result = Visit(context.expr());

            if (!result.IsSuccess)
            {
                return result;
            }

            return new TranspileResult() { IsSuccess = true, Text = string.Format("({0})", result.Text) };
        }
        public override TranspileResult VisitExpr_sign([NotNull] structured_textParser.Expr_signContext context)
        {
            var result = Visit(context.expr());

            if (!result.IsSuccess)
            {
                return result;
            }

            var opeText = string.Empty;
            if (!GetOperatorText(context.op.Type, false, out opeText))
            {
                return new TranspileResult() { Errors = new List<string>() { "Unknown Operator Type" } };
            }

            return new TranspileResult() { IsSuccess = true, Text = opeText + " " + result.Text };
        }

        public override TranspileResult VisitExpr_power([NotNull] structured_textParser.Expr_powerContext context)
        {
            var lhsResult = Visit(context.lhs);
            if (!lhsResult.IsSuccess)
            {
                return lhsResult;
            }
            var rhsResult = Visit(context.rhs);
            if (!rhsResult.IsSuccess)
            {
                return rhsResult;
            }

            return new TranspileResult() { IsSuccess = true, Text = string.Format("({0}) ^ ({1})", lhsResult.Text, rhsResult.Text) };
        }

        public override TranspileResult VisitExpr_muldiv([NotNull] structured_textParser.Expr_muldivContext context)
        {
            return Expr(context.lhs, context.rhs, context.op.Type);
        }

        public override TranspileResult VisitExpr_addsub([NotNull] structured_textParser.Expr_addsubContext context)
        {
            return Expr(context.lhs, context.rhs, context.op.Type);
        }

        public override TranspileResult VisitExpr_comp([NotNull] structured_textParser.Expr_compContext context)
        {
            return Expr(context.lhs, context.rhs, context.op.Type);
        }
        public override TranspileResult VisitExpr_eq_neq([NotNull] structured_textParser.Expr_eq_neqContext context)
        {
            return Expr(context.lhs, context.rhs, context.op.Type);
        }
        public override TranspileResult VisitExpr_boolean_add([NotNull] structured_textParser.Expr_boolean_addContext context)
        {
            return Expr(context.lhs, context.rhs, context.op.Type);
        }
        public override TranspileResult VisitExpr_boolean_exor([NotNull] structured_textParser.Expr_boolean_exorContext context)
        {
            return Expr(context.lhs, context.rhs, context.op.Type);
        }
        public override TranspileResult VisitExpr_boolean_or([NotNull] structured_textParser.Expr_boolean_orContext context)
        {
            return Expr(context.lhs, context.rhs, context.op.Type);
        }

        public override TranspileResult VisitArg_assign([NotNull] structured_textParser.Arg_assignContext context)
        {
            var result = Visit(context.arg);

            if (!result.IsSuccess)
            {
                return result;
            }

            string opeText;
            if (!GetOperatorText(context.op.Type, true, out opeText))
            {
                return new TranspileResult() { Errors = new List<string>() { "Unknown Operator Type" } };
            }

            return new TranspileResult()
            {
                IsSuccess = true,
                Text = context.IDENTIFIER().GetText() + " " + opeText + " " + result.Text
            };
        }

        public override TranspileResult VisitExpr_funccall([NotNull] structured_textParser.Expr_funccallContext context)
        {
            var result = new TranspileResult();
            var args_result = context._args.Select(arg => Visit(arg));

            var err_args = args_result.Where(obj => !obj.IsSuccess);
            if (err_args.Count() != 0)
            {
                foreach (var err in err_args) result.Errors.AddRange(err.Errors);
                return result;
            }

            return new TranspileResult()
            {
                IsSuccess = true,
                Text = string.Format("{0}({1})",
                    context.funcname.Text,
                    string.Join(",", args_result.Select(arg=>arg.Text))
                )
            };
        }

        override public TranspileResult VisitInput([NotNull] structured_textParser.InputContext context)
        {
            //そのままだと、戻り値がNULL。。。EOFを訪れるとNULLが返ってるのかな？
            var result = Visit(context.statements());

            if (result == null)
            {
                result = new TranspileResult();
                result.Errors.Add("unknown error.");
            }

            return result;
        }

        private TranspileResult Expr(ExprContext lhs, ExprContext rhs, int type)
        {
            var lhsResult = Visit(lhs);
            if (!lhsResult.IsSuccess)
            {
                return lhsResult;
            }
            var rhsResult = Visit(rhs);
            if (!rhsResult.IsSuccess)
            {
                return rhsResult;
            }

            string opeText;
            if (!GetOperatorText(type, false, out opeText))
            {
                return new TranspileResult() { Errors = new List<string>() { "Unknown Operator Type" } };
            }

            return new TranspileResult() { IsSuccess = true, Text = string.Format("({0}) {1} ({2})", lhsResult.Text, opeText, rhsResult.Text) };
        }

        private bool GetOperatorText(int type, bool isFunc, out string opeText)
        {
            opeText = string.Empty;
            switch (type)
            {
                case structured_textLexer.PLUS:
                    opeText = "+";
                    return true;
                case structured_textParser.MINUS:
                    opeText = "-";
                    return true;
                case structured_textLexer.NOT:
                    opeText = "NOT";
                    return true;
                case structured_textLexer.ASTERISK:
                    opeText = "*";
                    return true;
                case structured_textLexer.SLASH:
                    opeText = "/";
                    return true;
                case structured_textLexer.MOD:
                    opeText = "MOD";
                    return true;
                case structured_textLexer.LT:
                    opeText = "<";
                    return true;
                case structured_textLexer.LE:
                    opeText = "<=";
                    return true;
                case structured_textLexer.GT:
                    opeText = ">";
                    return true;
                case structured_textLexer.GE:
                    opeText = ">=";
                    return true;
                case structured_textLexer.EQ:
                    opeText = "=";
                    return true;
                case structured_textLexer.NEQ:
                    opeText = "<>";
                    return true;
                case structured_textLexer.AND:
                    opeText = "AND";
                    return true;
                case structured_textLexer.EXOR:
                    opeText = "XOR";
                    return true;
                case structured_textLexer.OR:
                    opeText = "OR";
                    return true;
                case structured_textLexer.ASSIGN:
                    opeText = (isFunc) ? ":=" : "=";
                    return true;
                case structured_textLexer.OUTREF:
                    opeText = ":=";
                    return true;
                default:
                    return false;
            }
        }
        #endregion
    }

    class TranspileResult
    {
        public bool IsSuccess { get; set; }

        public bool IsUnderFuncArgs { get; set; } = false;

        public string Text { get; set; }
        public List<string> Errors { get; set; } = new List<string>();
    }
}
